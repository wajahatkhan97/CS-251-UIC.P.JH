/*main.cpp*/

//
// Hashing program for specialized Illinois license plates,
// which processes an input file of license plates and fines.
// The output is the total fines per license plate, in 
// sorted order.
//
// Original author: Prof. Joe Hummel
// Modified by:     << Wajahat Khan >> 
//NETID : WKHAN25
//UIN: 674981418
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Project 05
//

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <cassert>

#include "ILplates.h"

using namespace std;


//
// hashInput:
//
void hashInput(string basename, ILplates& hashplates)
{
	string infilename = basename + ".txt";
	ifstream infile(infilename);

	if (!infile.good())
	{
		cout << endl;
		cout << "**Error: unable to open input file '" << infilename << "', exiting." << endl;
		cout << endl;
		exit(-1);
	}

	//
	// input the plates and fines:
	//
	cout << "Reading '" << infilename << "'..." << endl;

	string fine;
	string plate;

	getline(infile, fine);

	//
	// for each pair (fine, license plate), hash and store/update fine:
	//
	while (!infile.eof())
	{
		getline(infile, plate);

		//cout << fine << endl;
		//cout << plate << endl;

		// 
		// is plate valid?  Only process valid plates:
		//
		if (hashplates.Hash(plate) >= 0)  // yes:
		{
			int amount = hashplates.Search(plate);

			if (amount < 0)  // not found:
			{
				hashplates.Insert(plate, stoi(fine));
			}
			else  // we found it, so update total in hash table:
			{
				amount += stoi(fine);
			hashplates.Insert(plate, amount);
			}

		}//valid

		getline(infile, fine);
	}
}
///first helper function for the swap (bubble sort)
void swapplates(string *x, string *y)
{
	string temp = *x;
	*x = *y;
	*y = temp;
}
//same thing helper function to swap amount(bubble sort)
void swapamounts(int *x, int *y)  //swapping the amounts according to the plates
{
	int temp = *x;
	*x = *y;
	*y = temp;
}
void sorthash(vector<string>&plates, vector<int>&amounts)   //bubble sort......can use insertion too but bubble is more easier
{
	cout << "Sorting '" << "'..." << endl;

	// A function to implement bubble sort  

		int i, j;
		for (i = 0; i < plates.size() - 1; i++)
		{
			// Last i elements are already in place  
			for (j = 0; j < plates.size() - i - 1; j++)
			{
				if (plates[j] > plates[j + 1])
				{
					swapplates(&plates[j], &plates[j + 1]);
					swapamounts(&amounts[j], &amounts[j + 1]);
				}
			}
		}

}
void output(string outfil, vector<string>plates, vector<int>amount) //outputting to the file........
{
	string outf = outfil + "-output.txt";
	ofstream outfile(outf);
	cout << "Writing '" << outf << "'..." << endl;
	for (size_t i = 0; i < plates.size(); ++i)
	{
		outfile << "\"" << plates[i] << "\"" << " $" << amount[i] << endl;


	}
}	

// you have to do error checking for tickets 8 something is missing in error checking function
int main()

{
	int    N;        // = 10000;
	string basename; // = "tickets1";

	cout << "Enter hashtable size> ";
	cin >> N;

	hashtable<string, int>  ht(N);
	
	ILplates                hashplates(ht);

	cout << "Enter base filename> ";
	cin >> basename;
	cout << endl;

	//
	// process input file of fines and license plates:
	//
	hashInput(basename, hashplates);
	
	//
	// debugging:
	//
	vector<string> plates = ht.Keys();
	vector<int> amounts = ht.Values();
	sorthash(plates,amounts);
	output(basename, plates, amounts);

	//
	// done:
	//
	return 0;
}