/*ILplates.cpp*/

//
// Hashing functions to store (license plate, amount) pairs
// using linear probing.
//
// << Wajahat Khan >>
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Project 05
//

#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include "ILplates.h"
#include <algorithm>
#include <cstdlib>
using namespace std;


//
// Hash:
//
// Given a specialized Illinois license plate, returns an index into
// the underyling hash table.  If the given plate does not follow the
// formatting rules given below, -1 is returned.
//
// Personalized:
//   letters and numbers, with a space between the letters 
//   and numbers.  Format: 1-5 letters plus 1..99 *OR* 
//   6 letters plus 1..9
//
//   Examples: A 1, B 99, ZZZZZ 1, ABCDEF 3
//
// Vanity:
//   Format: 1-3 numbers *OR* 1-7 letters
// 
//   Examples: 007, 1, 42, X, AAA, ZZZEFGH
//

int errorchecking(string plate)
{
	 ///passing tickets 8 file but still you have to check boyyyy okay ?
	vector<char>check;
	vector<char>checkint;
	long index = 0;
    int count = 1;
	int pos = 0;
	int pos1 = 0;
	int afpos = 0;
	string word[2];
    int index_t = 11233353;
	//start by doing personalized license plates

	if (plate.length() > 8 || plate.length() < 1) //checking the first condition for the length
	{
		return -1;
	}
	else
	{
		if (!isdigit(plate[0]))  //okay so here is the interesting part i'm checking the first element to differentiate between vanity and personalized
		{
           /// cout << plate.length()<<endl;
			for (int i = 0; i < plate.length(); i++)
			{ //some personalized stuff going on here with checking conditions
				if (!isdigit(plate[i]) && plate[i] != ' ' && isalpha(plate[i]) && afpos == 0  )  //afpos == 1 meaning we already had the space 
				{
					if (islower(plate[i]))
					{
						return -1;
					}
					else
					{
						check.push_back(plate[i]);
						pos++;
					}
				}
				else if (plate[i] == ' ' && afpos != 1 )  //afpos !=1 meaning that you already encountered a space
				{
						afpos++;
						continue;
					
						
				}
				else if (isdigit(plate[i]) && plate[i] < 99 && afpos != 0) // afpos != 0 meaning we haven't hit the space yet.
				{
					if (!isalpha(plate[i]) )
					{
						checkint.push_back(plate[i]);
						afpos++;
					}
				}

				else
				{
					return -1;
				}

			}
			///so after the ' ' is encountered we will store our data in two different "in string word" 
			word[0].append(plate, 0, pos);
			//check the length of the word 0 must be 1-5 then 1-99 number or 1-6 then 1-9 numbers
			word[1].append(plate, pos, afpos);  //word[1] contain after the space numeric values
			

			int checking = 0;
            
			if (!word[1].empty() )
			{
				 checking = stoi(word[1]);  //again some condition checking
				if ((checking > 9 || checking < 1 && word[0].length() <= 6) && (word[0].length() <= 5 && checking > 100 || checking < 1))   //checking conditions for length personalized
				{
					return -1;
				}
				
			}
			else if (!word[0].empty() && word[0].length() >= 8) //condition checking
			{
				return -1;
			}
			
			/////////////////create the index loop here

			for (int i = 0; i < check.size(); i++)  //here the indexing begins
			{
				
				if (!word[0].empty())
				{
                    
					index_t  += ((check[i])*(237-checking)*(43 * checking+33))+i;
				}
				else
				{
					index_t  += ((check[i])*(237-count)*(43* count+33)+i); //alot of numbers are multiplying 
                    //trying to generate unqiue values
				}
				count = count++;
			}
			
			return index_t -1;
		}
	}
    int count1 = 1;
	if (isdigit(plate[0]) && plate.length() <= 3)//vanity
	{
		for (int i = 0; i < plate.length(); i++)
		{
			if (isalpha(plate[i]))
			{
				return -1;  //wrong input
			}
			else
			{
				checkint.push_back(plate[i]);
				pos1++;
                //vanity case
			}
		}

		for (int i = 0; i < checkint.size(); i++)
		{
			//vanity case indexing just for the numeric values
			index_t  += ((plate[i])*(237-count1)*(43 * count1+33)+i);
		count1++;
		}
			
	//	cout << word[1].append(plate,0,pos1)<< endl;
		//cout << " index ?? " << (index) << endl;

		return index_t-1;  //return the index
	}
	else
	{
		return -1;  //return -1 because its invalid
	}
}
	

int ILplates::Hash(string plate)  //so at this point we recieve the input we have to check here right ??
{
	long index = 0;
	index = errorchecking(plate);
	if (index == -1)  //okay we're still having a problem we are reading error checking twice both in search and Hash condition (SEE PROJECT5HASINH.CPP)
	{
		return -1;
	}
		//do the indexing
	else
	{
		index = (index) % HT.Size();
		//cout << " index ?? " << (index) << endl;
		return index;
	}
	return index % HT.Size();
	//cout << "THE INDEX IS: " << index << endl;
 }


//
// Search
// 
// Hashes and searches for the given license plate; returns the 
// associated value for this plate if found, or -1 if not found.

int ILplates::Search(string plate)  //this is fine don't do anything to it
{

	
    long index = 0;
 index = Hash(plate);  //getting the index again 
	//int bprobbed = 0;
	bool empty;
	string Keys;
	int Values;
	//int count = 0;
	do
	{
	
		HT.Get(index, empty, Keys, Values); //accessing the hashtable
		if (empty == true)
		{
			break;
		}
		else if (empty == false && Keys == plate)
		{
			return Values;
		}
		else if(empty == false)
		{
			index = (index + 1) % HT.Size();
		
		}
		//count++;
		//count += count;
	//	cout << "THIS IS THE COUNTS OF SEARCH: " << count<< endl; //checking
	}while (empty != true);  //true meaning we found the empty space ???
	
	return -1;
}
	



//
// Insert
//
// Inserts the given (plate, newValue) into the hash table,
// overwriting an existing value if there.
//

void ILplates::Insert(string plate, int newValue)
{
long index =0;
	 index = Hash(plate);	//getting the index again
    //int bprobbed = 0;
	bool empty = false;
	string Keys;
	int Values;
	//int count = 0;
	
	do
	{

		
        HT.Get(index, empty, Keys, Values); //accessing the hashtable
		 if (empty == false && Keys == plate)
		{
			HT.Set(index, Keys, newValue);
			break;
		}

		 else if (empty == true) //found an empty space
		 {
			 HT.Set(index, plate, newValue);
			 break;
		 }
		 else 
		 {
			 index = (index + 1) % HT.Size();
		 }
		//cout << "which one ?? " << index << "probbed" << bprobbed<<endl;
			//bprobbed++;
	} while (empty != true);
	
}
	//
	// TODO:
	//

